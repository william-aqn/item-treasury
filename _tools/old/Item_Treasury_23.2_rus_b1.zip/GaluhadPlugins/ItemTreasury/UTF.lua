------------------------------------------------------------------------------
-- UTF-8 Strings.
-- This single file is completly free. Please use/modify without credits. Ooz
------------------------------------------------------------------------------

-- UTF 8 Stings. Names based on HTML Entities
UTF8_iexcl = string.char(194)..string.char(161); -- Ў	
UTF8_cent = string.char(194)..string.char(162); -- ў	
UTF8_pound = string.char(194)..string.char(163); -- Ј	
UTF8_curren = string.char(194)..string.char(164); -- ¤	
UTF8_yen = string.char(194)..string.char(165); -- Ґ	
UTF8_brvbar = string.char(194)..string.char(166); -- ¦	
UTF8_sect = string.char(194)..string.char(167); -- §	
UTF8_uml = string.char(194)..string.char(168); -- Ё	
UTF8_copy = string.char(194)..string.char(169); -- ©	
UTF8_ordf = string.char(194)..string.char(170); -- Є	
UTF8_laquo = string.char(194)..string.char(171); -- «	
UTF8_not = string.char(194)..string.char(172); -- ¬	
UTF8_shy = string.char(194)..string.char(173); -- ­	
UTF8_reg = string.char(194)..string.char(174); -- ®	
UTF8_macr = string.char(194)..string.char(175); -- Ї	
UTF8_deg = string.char(194)..string.char(176); -- °	
UTF8_plusmn = string.char(194)..string.char(177); -- ±	
UTF8_sup2 = string.char(194)..string.char(178); -- І	
UTF8_sup3 = string.char(194)..string.char(179); -- і	
UTF8_acute = string.char(194)..string.char(180); -- ґ	
UTF8_micro = string.char(194)..string.char(181); -- µ	
UTF8_para = string.char(194)..string.char(182); -- ¶	
UTF8_middot = string.char(194)..string.char(183); -- ·	
UTF8_cedil = string.char(194)..string.char(184); -- ё	
UTF8_sup1 = string.char(194)..string.char(185); -- №	
UTF8_ordm = string.char(194)..string.char(186); -- є	
UTF8_raquo = string.char(194)..string.char(187); -- »	
UTF8_frac14 = string.char(194)..string.char(188); -- ј	
UTF8_frac12 = string.char(194)..string.char(189); -- Ѕ	
UTF8_frac34 = string.char(194)..string.char(190); -- ѕ	
UTF8_iquest = string.char(194)..string.char(191); -- ї	
UTF8_Agrave = string.char(195)..string.char(128); -- А	
UTF8_Aacute = string.char(195)..string.char(129); -- Б	
UTF8_Acirc = string.char(195)..string.char(130); -- В	
UTF8_Atilde = string.char(195)..string.char(131); -- Г	
UTF8_Auml = string.char(195)..string.char(132); -- Д	
UTF8_Aring = string.char(195)..string.char(133); -- Е	
UTF8_AElig = string.char(195)..string.char(134); -- Ж	
UTF8_Ccedil = string.char(195)..string.char(135); -- З	
UTF8_Egrave = string.char(195)..string.char(136); -- И	
UTF8_Eacute = string.char(195)..string.char(137); -- Й	
UTF8_Ecirc = string.char(195)..string.char(138); -- К	
UTF8_Euml = string.char(195)..string.char(139); -- Л	
UTF8_Igrave = string.char(195)..string.char(140); -- М	
UTF8_Iacute = string.char(195)..string.char(141); -- Н	
UTF8_Icirc = string.char(195)..string.char(142); -- О	
UTF8_Iuml = string.char(195)..string.char(143); -- П	
UTF8_ETH = string.char(195)..string.char(144); -- Р	
UTF8_Ntilde = string.char(195)..string.char(145); -- С	
UTF8_Ograve = string.char(195)..string.char(146); -- Т	
UTF8_Oacute = string.char(195)..string.char(147); -- У	
UTF8_Ocirc = string.char(195)..string.char(148); -- Ф	
UTF8_Otilde = string.char(195)..string.char(149); -- Х	
UTF8_Ouml = string.char(195)..string.char(150); -- Ц	
UTF8_times = string.char(195)..string.char(151); -- Ч	
UTF8_Oslash = string.char(195)..string.char(152); -- Ш	
UTF8_Ugrave = string.char(195)..string.char(153); -- Щ	
UTF8_Uacute = string.char(195)..string.char(154); -- Ъ	
UTF8_Ucirc = string.char(195)..string.char(155); -- Ы	
UTF8_Uuml = string.char(195)..string.char(156); -- Ь	
UTF8_Yacute = string.char(195)..string.char(157); -- Э	
UTF8_THORN = string.char(195)..string.char(158); -- Ю	
UTF8_szlig = string.char(195)..string.char(159); -- Я	
UTF8_agrave = string.char(195)..string.char(160); -- а	
UTF8_aacute = string.char(195)..string.char(161); -- б	
UTF8_acirc = string.char(195)..string.char(162); -- в	
UTF8_atilde = string.char(195)..string.char(163); -- г	
UTF8_auml = string.char(195)..string.char(164); -- д	
UTF8_aring = string.char(195)..string.char(165); -- е	
UTF8_aelig = string.char(195)..string.char(166); -- ж	
UTF8_ccedil = string.char(195)..string.char(167); -- з	
UTF8_egrave = string.char(195)..string.char(168); -- и	
UTF8_eacute = string.char(195)..string.char(169); -- й	
UTF8_ecirc = string.char(195)..string.char(170); -- к	
UTF8_euml = string.char(195)..string.char(171); -- л	
UTF8_igrave = string.char(195)..string.char(172); -- м	
UTF8_iacute = string.char(195)..string.char(173); -- н	
UTF8_icirc = string.char(195)..string.char(174); -- о	
UTF8_iuml = string.char(195)..string.char(175); -- п	
UTF8_eth = string.char(195)..string.char(176); -- р	
UTF8_ntilde = string.char(195)..string.char(177); -- с	
UTF8_ograve = string.char(195)..string.char(178); -- т	
UTF8_oacute = string.char(195)..string.char(179); -- у	
UTF8_ocirc = string.char(195)..string.char(180); -- ф	
UTF8_otilde = string.char(195)..string.char(181); -- х	
UTF8_ouml = string.char(195)..string.char(182); -- ц	
UTF8_divide = string.char(195)..string.char(183); -- ч	
UTF8_oslash = string.char(195)..string.char(184); -- ш	
UTF8_ugrave = string.char(195)..string.char(185); -- щ	
UTF8_uacute = string.char(195)..string.char(186); -- ъ	
UTF8_ucirc = string.char(195)..string.char(187); -- ы	
UTF8_uuml = string.char(195)..string.char(188); -- ь	
UTF8_yacute = string.char(195)..string.char(189); -- э	
UTF8_thorn = string.char(195)..string.char(190); -- ю	
UTF8_yuml = string.char(195)..string.char(191); -- я	

-- encoded character to UTF-8
UTF8_encodingMap = {
	 {"Ў",UTF8_iexcl}
	,{"ў",UTF8_cent}
	,{"Ј",UTF8_pound}
	,{"¤",UTF8_curren}
	,{"Ґ",UTF8_yen}
	,{"¦",UTF8_brvbar}
	,{"§",UTF8_sect}
	,{"Ё",UTF8_uml}
	,{"©",UTF8_copy}
	,{"Є",UTF8_ordf}
	,{"«",UTF8_laquo}
	,{"¬",UTF8_not}
	,{"­",UTF8_shy}
	,{"®",UTF8_reg}
	,{"Ї",UTF8_macr}
	,{"°",UTF8_deg}
	,{"±",UTF8_plusmn}
	,{"); -- І",UTF8_sup2}
	,{"і",UTF8_sup3}
	,{"ґ",UTF8_acute}
	,{"µ",UTF8_micro}
	,{"¶",UTF8_para}
	,{"·",UTF8_middot}
	,{"ё",UTF8_cedil}
	,{"№",UTF8_sup1}
	,{"є",UTF8_ordm}
	,{"»",UTF8_raquo}
	,{"ј",UTF8_frac14}
	,{"Ѕ",UTF8_frac12}
	,{"ѕ",UTF8_frac34}
	,{"ї",UTF8_iquest}
	,{"А",UTF8_Agrave}
	,{"Б",UTF8_Aacute}
	,{"В",UTF8_Acirc}
	,{"Г",UTF8_Atilde}
	,{"Д",UTF8_Auml}
	,{"Е",UTF8_Aring}
	,{"Ж",UTF8_AElig}
	,{"З",UTF8_Ccedil}
	,{"И",UTF8_Egrave}
	,{"Й",UTF8_Eacute}
	,{"К",UTF8_Ecirc}
	,{"Л",UTF8_Euml}
	,{"М",UTF8_Igrave}
	,{"Н",UTF8_Iacute}
	,{"О",UTF8_Icirc}
	,{"П",UTF8_Iuml}
	,{"Р",UTF8_ETH}
	,{"С",UTF8_Ntilde}
	,{"Т",UTF8_Ograve}
	,{"У",UTF8_Oacute}
	,{"Ф",UTF8_Ocirc}
	,{"Х",UTF8_Otilde}
	,{"Ц",UTF8_Ouml}
	,{"Ч",UTF8_times}
	,{"Ш",UTF8_Oslash}
	,{"Щ",UTF8_Ugrave}
	,{"Ъ",UTF8_Uacute}
	,{"Ы",UTF8_Ucirc}
	,{"Ь",UTF8_Uuml}
	,{"Э",UTF8_Yacute}
	,{"Ю",UTF8_THORN}
	,{"Я",UTF8_szlig}
	,{"а",UTF8_agrave}
	,{"б",UTF8_aacute}
	,{"в",UTF8_acirc}
	,{"г",UTF8_atilde}
	,{"д",UTF8_auml}
	,{"е",UTF8_aring}
	,{"ж",UTF8_aelig}
	,{"з",UTF8_ccedil}
	,{"и",UTF8_egrave}
	,{"й",UTF8_eacute}
	,{"к",UTF8_ecirc}
	,{"л",UTF8_euml}
	,{"м",UTF8_igrave}
	,{"н",UTF8_iacute}
	,{"о",UTF8_icirc}
	,{"п",UTF8_iuml}
	,{"р",UTF8_eth}
	,{"с",UTF8_ntilde}
	,{"т",UTF8_ograve}
	,{"у",UTF8_oacute}
	,{"ф",UTF8_ocirc}
	,{"х",UTF8_otilde}
	,{"ц",UTF8_ouml}
	,{"ч",UTF8_divide}
	,{"ш",UTF8_oslash}
	,{"щ",UTF8_ugrave}
	,{"ъ",UTF8_uacute}
	,{"ы",UTF8_ucirc}
	,{"ь",UTF8_uuml}
	,{"э",UTF8_yacute}
	,{"ю",UTF8_thorn}
	,{"я",UTF8_yuml}
};

UTF8_upperMap = {
	 {"Ў",UTF8_iexcl}
	,{"ў",UTF8_cent}
	,{"Ј",UTF8_pound}
	,{"¤",UTF8_curren}
	,{"Ґ",UTF8_yen}
	,{"¦",UTF8_brvbar}
	,{"§",UTF8_sect}
	,{"Ё",UTF8_uml}
	,{"©",UTF8_copy}
	,{"Є",UTF8_ordf}
	,{"«",UTF8_laquo}
	,{"¬",UTF8_not}
	,{"­",UTF8_shy}
	,{"®",UTF8_reg}
	,{"Ї",UTF8_macr}
	,{"°",UTF8_deg}
	,{"±",UTF8_plusmn}
	,{"); -- І",UTF8_sup2}
	,{"і",UTF8_sup3}
	,{"ґ",UTF8_acute}
	,{"µ",UTF8_micro}
	,{"¶",UTF8_para}
	,{"·",UTF8_middot}
	,{"ё",UTF8_cedil}
	,{"№",UTF8_sup1}
	,{"є",UTF8_ordm}
	,{"»",UTF8_raquo}
	,{"ј",UTF8_frac14}
	,{"Ѕ",UTF8_frac12}
	,{"ѕ",UTF8_frac34}
	,{"ї",UTF8_iquest}
	,{"А",UTF8_Agrave}
	,{"Б",UTF8_Aacute}
	,{"В",UTF8_Acirc}
	,{"Г",UTF8_Atilde}
	,{"Д",UTF8_Auml}
	,{"Е",UTF8_Aring}
	,{"Ж",UTF8_AElig}
	,{"З",UTF8_Ccedil}
	,{"И",UTF8_Egrave}
	,{"Й",UTF8_Eacute}
	,{"К",UTF8_Ecirc}
	,{"Л",UTF8_Euml}
	,{"М",UTF8_Igrave}
	,{"Н",UTF8_Iacute}
	,{"О",UTF8_Icirc}
	,{"П",UTF8_Iuml}
	,{"Р",UTF8_ETH}
	,{"С",UTF8_Ntilde}
	,{"Т",UTF8_Ograve}
	,{"У",UTF8_Oacute}
	,{"Ф",UTF8_Ocirc}
	,{"Х",UTF8_Otilde}
	,{"Ц",UTF8_Ouml}
	,{"Ч",UTF8_times}
	,{"Ш",UTF8_Oslash}
	,{"Щ",UTF8_Ugrave}
	,{"Ъ",UTF8_Uacute}
	,{"Ы",UTF8_Ucirc}
	,{"Ь",UTF8_Uuml}
	,{"Э",UTF8_Yacute}
	,{"Ю",UTF8_THORN}
	,{"Я",UTF8_szlig}
	,{"а",UTF8_Agrave}
	,{"б",UTF8_Aacute}
	,{"в",UTF8_Acirc}
	,{"г",UTF8_Atilde}
	,{"д",UTF8_Auml}
	,{"е",UTF8_Aring}
	,{"ж",UTF8_AElig}
	,{"з",UTF8_Ccedil}
	,{"и",UTF8_Egrave}
	,{"й",UTF8_Eacute}
	,{"к",UTF8_Ecirc}
	,{"л",UTF8_Euml}
	,{"м",UTF8_Igrave}
	,{"н",UTF8_Iacute}
	,{"о",UTF8_Icirc}
	,{"п",UTF8_Iuml}
	,{"р",UTF8_ETH}
	,{"с",UTF8_Ntilde}
	,{"т",UTF8_Ograve}
	,{"у",UTF8_Oacute}
	,{"ф",UTF8_Ocirc}
	,{"х",UTF8_Otilde}
	,{"ц",UTF8_Ouml}
	,{"ч",UTF8_times}
	,{"ш",UTF8_Oslash}
	,{"щ",UTF8_Ugrave}
	,{"ъ",UTF8_Uacute}
	,{"ы",UTF8_Ucirc}
	,{"ь",UTF8_Uuml}
	,{"э",UTF8_Yacute}
	,{"ю",UTF8_THORN}
	,{"я",UTF8_szlig}
};

function UTF8UPPER(utf8String)
	local encodedresult = "";
	local sequence = false;
	local sequencePrefix = "";
	for c in string.gmatch(utf8String, ".") do 
		b = string.byte(c);
		if sequence then
			for i,v in ipairs(UTF8_upperMap) do
				if sequencePrefix..c == v[2] then
					encodedresult = encodedresult..v[1];
					break;
				end
			end
			sequence = false;
			sequencePrefix = "";
		elseif b == 154 or b == 195 then
			sequence = true;
			sequencePrefix = c;
		else
			encodedresult = encodedresult..c;
		end
	end
	return encodedresult;
end

function ToUTF8(encodedString)
	local utf8result = "";
	for c in string.gmatch(encodedString, ".") do 
		local isUnmapped = true;
		for i,v in ipairs(UTF8_encodingMap) do
			if c==v[1] then
				utf8result=utf8result..v[2];
				isUnmapped = false;
				break;
			end
		end
		if isUnmapped then
			utf8result=utf8result..c;
		end
	end
	return utf8result;
end

function FromUTF8(utf8String)
	local encodedresult = "";
	local sequence = false;
	local sequencePrefix = "";
	for c in string.gmatch(utf8String, ".") do 
		b = string.byte(c);
		if sequence then
			for i,v in ipairs(UTF8_encodingMap) do
				if sequencePrefix..c == v[2] then
					encodedresult = encodedresult..v[1];
					break;
				end
			end
			sequence = false;
			sequencePrefix = "";
		elseif b == 154 or b == 195 then
			sequence = true;
			sequencePrefix = c;
		else
			encodedresult = encodedresult..c;
		end
	end
	return encodedresult;
end
