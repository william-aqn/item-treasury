1) Добавить определение локали в \GaluhadPlugins\ItemTreasury\Utils\GeneralFunctions.lua
дописав строки:

	if Turbine.Shell.IsCommand("чирик") then
		LANGUAGE = 4;
	end 

2) Перевести строки в GaluhadPlugins\ItemTreasury\Strings.lua
3) Перевести базы данных в корневом каталоге плагина
4) Переписать поиск в GaluhadPlugins\ItemTreasury\Windows\MainWin.lua
	Line 284: 	for w in string.gmatch(searchStr, "%S+") do