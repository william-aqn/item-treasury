
-- This function checks any loaded data from save to ensure it is compatible with the current version
function VerifyData()

	SETTINGS["__VERSION"] = nil;

end


