
-- [ID] = {[1] = "";				[2] = "";				[3] = "";				[4] = "";};

-- 1 = English; 	2 = French; 	3 = German; 	4 = Russian

_STRINGS =
{

	[1] = -- add on messages
	{
		[1] = 	{[1] = "Error loading saved settings";							[2] = "Error loading saved settings";						[3] = "Error loading saved settings";							[4] = "Ошибка загрузки настроек";};
		[2] = 	{[1] = "Please report this message at lotrointerface.com";		[2] = "Please report this message at lotrointerface.com";	[3] = "Please report this message at lotrointerface.com";		[4] = "Пожалуйста, сообщите об ошибке на lotrointerface.com";};
		[3] = 	{
			[1] = PLUGINNAME .. " does not support the character played in this session";
			[2] = PLUGINNAME .. " does not support the character played in this session";
			[3] = PLUGINNAME .. " does not support the character played in this session";
			[4] = PLUGINNAME .. " не поддерживает данного персонажа";};

		[4] = 	{[1] = "No items selected";					[2] = "No items selected";					[3] = "No items selected";					[4] = "Нет выбранных предметов";};
		[5] = {
			[1] = "Shows/hides "..PLUGINNAME.." \nitem (search query) -- usage: /item <id/name>";
			[2] = "Shows/hides "..PLUGINNAME.." \nitem (search query) -- usage: /item <id/name>";
			[3] = "Shows/hides "..PLUGINNAME.." \nitem (search query) -- usage: /item <id/name>";
			[4] = "Показать/скрыть "..PLUGINNAME.." \nitem (строка поиска) -- использование: /item <id/название>";};

		[6] = {
			[1] = "Use command '/item' to show/hide the main window";
			[2] = "Use command '/item' to show/hide the main window";
			[3] = "Use command '/item' to show/hide the main window";
			[4] = "Наберите '/item' чтобы показать/скрыть главное окно";};

		[7] = {
			[1] = "Use command '/item <id/name>' to search for an item";
			[2] = "Use command '/item <id/name>' to search for an item";
			[3] = "Use command '/item <id/name>' to search for an item";
			[4] = "Наберите '/item <id/название>' чтобы найти предмет";};


	};

};


_TOOLTIPS =
{
	[1] = {[1] = "First page";							[2] = "First page";							[3] = "First page";							[4] = "Первая страница";};
	[2] = {[1] = "Previous page";						[2] = "Previous page";						[3] = "Previous page";						[4] = "Предыдущая страница";};
	[3] = {[1] = "Next page";							[2] = "Next page";							[3] = "Next page";							[4] = "Следующая страница";};
	[4] = {[1] = "Last page";							[2] = "Last page";							[3] = "Last page";							[4] = "Последняя страница";};
	[5] = {[1] = "Quantity";							[2] = "Quantity";							[3] = "Quantity";							[4] = "Количество";};

};


_LABELS =
{
	[1] =	{[1] = "Items found";						[2] = "Items found";						[3] = "Items found";						[4] = "Найдено предметов";};
	[2] = 	{[1] = "Showing Results";					[2] = "Showing Results";					[3] = "Showing Results";					[4] = "Showing Results";};
	[3] = 	{[1] = "All";								[2] = "All";								[3] = "All";								[4] = "Все";};
	[4] = 	{[1] = "Go";								[2] = "Go";									[3] = "Go";									[4] = "Вперед";};
	[5] = 	{[1] = "Reset";								[2] = "Reset";								[3] = "Reset";								[4] = "Сбросить";};
	[6] = 	{[1] = "Select All";						[2] = "Select All";							[3] = "Select All";							[4] = "Выбрать все";};
	[7] = 	{[1] = "Select None";						[2] = "Select None";						[3] = "Select None";						[4] = "Снять выбор";};
	[8] = 	{[1] = "List Items";						[2] = "List Items";							[3] = "List Items";							[4] = "Вывести список";};
	[9] = 	{[1] = "Selected items";					[2] = "Selected items";						[3] = "Selected items";						[4] = "Выбранные предметы";};
	[10] = 	{[1] = "Print IDs";							[2] = "Print IDs";							[3] = "Print IDs";							[4] = "Напечатать ID";};
	[11] = 	{[1] = "Database";							[2] = "Database";							[3] = "Database";							[4] = "База данных";};
	[12] = 	{[1] = "Update";							[2] = "Update";								[3] = "Update";								[4] = "Update";};
	[13] = 	{[1] = "Full";								[2] = "Full";								[3] = "Full";								[4] = "Вся";};

	[14] = {
			[1] = "Invalid number entered";
			[2] = "Invalid number entered";
			[3] = "Invalid number entered";
			[4] = "Введен некорректный номер";};

	[15] = 	{[1] = "Item Level";						[2] = "Item Level";							[3] = "Item Level";							[4] = "Уровень предмета";};
	[16] = 	{[1] = "Armour";							[2] = "Armour";								[3] = "Armour";								[4] = "Снаряжение";};
	[17] = 	{[1] = "Min. Level";						[2] = "Min. Level";							[3] = "Min. Level";							[4] = "Мин. уровень";};
	[18] = 	{[1] = "Preview";							[2] = "Preview";							[3] = "Preview";							[4] = "Осмотр";};
	[19] = 	{[1] = "Item Preview";						[2] = "Item Preview";						[3] = "Item Preview";						[4] = "Осмотреть предмет";};

};

_CHATCHANNELS =
{			--English				-- French				-- German				-- Russian
	[1] =  {[1] = "World";			[2] = "World";			[3] = "World"; 			[4] = "Мир";};
	[2] =  {[1] = "Trade";			[2] = "Trade";			[3] = "Trade"; 			[4] = "Торговля";};
	[3] =  {[1] = "LFF";			[2] = "LFF";			[3] = "LFF"; 			[4] = "LFF";};
	[4] =  {[1] = "Kinship";		[2] = "Kinship";		[3] = "Kinship"; 		[4] = "Содружество";};
	[5] =  {[1] = "Officer";		[2] = "Officer";		[3] = "Officer"; 		[4] = "Офицеры";};
	[6] =  {[1] = "Fellowship";		[2] = "Fellowship";		[3] = "Fellowship";		[4] = "Братство";};
	[7] =  {[1] = "Raid";			[2] = "Raid";			[3] = "Raid"; 			[4] = "Рейд";};
	[8] =  {[1] = "OOC";			[2] = "OOC";			[3] = "OOC"; 			[4] = "OOC";};
	[9] =  {[1] = "Regional";		[2] = "Regional";		[3] = "Regional"; 		[4] = "Регион";};
	[10] = {[1] = "Say";			[2] = "Say";			[3] = "Say"; 			[4] = "Сказать";};
	[11] = {[1] = "User Chat 1";	[2] = "User Chat 1";	[3] = "User Chat 1";	[4] = "User Chat 1";};
	[12] = {[1] = "User Chat 2";	[2] = "User Chat 2";	[3] = "User Chat 2";	[4] = "User Chat 2";};
	[13] = {[1] = "User Chat 3";	[2] = "User Chat 3";	[3] = "User Chat 3";	[4] = "User Chat 3";};
	[14] = {[1] = "User Chat 4";	[2] = "User Chat 4";	[3] = "User Chat 4";	[4] = "User Chat 4";};
	[15] = {[1] = "User Chat 5";	[2] = "User Chat 5";	[3] = "User Chat 5";	[4] = "User Chat 5";};
	[16] = {[1] = "User Chat 6";	[2] = "User Chat 6";	[3] = "User Chat 6";	[4] = "User Chat 6";};
	[17] = {[1] = "User Chat 7";	[2] = "User Chat 7";	[3] = "User Chat 7";	[4] = "User Chat 7";};
	[18] = {[1] = "User Chat 8";	[2] = "User Chat 8";	[3] = "User Chat 8";	[4] = "User Chat 8";};
};

_CHATCOMMANDS =
{			--English			-- French				-- German				-- Russian
	[1] =  {[1] = "/wd";		[2] = "/wd";			[3] = "/wd"; 			[4] = "/wd";};
	[2] =  {[1] = "/trade";		[2] = "trade";			[3] = "trade"; 			[4] = "trade";};
	[3] =  {[1] = "/lff";		[2] = "/lff";			[3] = "/lff"; 			[4] = "/lff";};
	[4] =  {[1] = "/k";			[2] = "/k";				[3] = "/k"; 			[4] = "/k";};
	[5] =  {[1] = "/o";			[2] = "/o";				[3] = "/o"; 			[4] = "/o";};
	[6] =  {[1] = "/f";			[2] = "/f";				[3] = "/f";				[4] = "/f";};
	[7] =  {[1] = "/ra";		[2] = "/ra";			[3] = "/ra"; 			[4] = "/ra";};
	[8] =  {[1] = "/ooc";		[2] = "/ooc";			[3] = "/ooc"; 			[4] = "/ooc";};
	[9] =  {[1] = "/regional";	[2] = "/regional";		[3] = "/regional"; 		[4] = "/regional";};
	[10] = {[1] = "/say";		[2] = "/say";			[3] = "/say"; 			[4] = "/say";};
	[11] = {[1] = "/1";			[2] = "/1";				[3] = "/1";				[4] = "/1";};
	[12] = {[1] = "/2";			[2] = "/2";				[3] = "/2";				[4] = "/2";};
	[13] = {[1] = "/3";			[2] = "/3";				[3] = "/3";				[4] = "/3";};
	[14] = {[1] = "/4";			[2] = "/4";				[3] = "/4";				[4] = "/4";};
	[15] = {[1] = "/5";			[2] = "/5";				[3] = "/5";				[4] = "/5";};
	[16] = {[1] = "/6";			[2] = "/6";				[3] = "/6";				[4] = "/6";};
	[17] = {[1] = "/7";			[2] = "/7";				[3] = "/7";				[4] = "/7";};
	[18] = {[1] = "/8";			[2] = "/8";				[3] = "/8";				[4] = "/8";};
};
