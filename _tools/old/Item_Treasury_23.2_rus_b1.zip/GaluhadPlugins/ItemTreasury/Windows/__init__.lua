
import (PLUGINDIR..".Windows.Item");
import (PLUGINDIR..".Windows.MainWin");

function DrawWindows()
	DrawItem();
	DrawMainWin();
end
