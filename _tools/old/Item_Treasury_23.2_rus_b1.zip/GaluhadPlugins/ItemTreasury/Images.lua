
_IMAGES =
{
	["BACKGROUNDS"] =
		{
		["HEADER"] = RESOURCEDIR .. "Scan_Header.tga";
		["PAGENATE"] = RESOURCEDIR .. "PagenateBack.tga";
		};

};

