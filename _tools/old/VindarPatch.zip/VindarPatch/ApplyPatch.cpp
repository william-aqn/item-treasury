#include <iostream>
#include <windows.h>
#include <string>
#include <vector>
#include <stack>
#include <windows.h>
#include <Shlobj.h>
#include <sstream>
using namespace std;

const string DIRECTORY   = "VindarPatch";
const string PATCHFILE   = "Patch";
const string METHOD_SAVE = "PatchDataSave";
const string METHOD_LOAD = "PatchDataLoad";

std::string LoadFile(std::string filename)
    {
     string text;
     text.reserve(1000000);
     char a;
     FILE * handle = fopen(filename.c_str(),"rb");
     if (handle == NULL) {MessageBox(NULL,"Error 1","",MB_OK); exit(0);}
     while( fread(&a,1,1,handle) != 0) {text +=a;}
     fclose(handle);
     return text;
    }

void SaveFile(std::string filename,std::string text)
    {
     FILE * handle = fopen(filename.c_str(),"wb");
     if (handle == NULL) {MessageBox(NULL,"Error 2","",MB_OK); exit(0);}
     if (fwrite(text.c_str(),1,text.length(),handle) != text.length()) {MessageBox(NULL,"Error 3","",MB_OK); exit(0);}
     fclose(handle);
     return;
    }

int Replace(string & text,string olds,string news)
{
    int nb = 0;
    while(1)
        {
        size_t pos = text.find(olds);
        if (pos == string::npos) {return nb;}
        text.replace(pos,olds.length(),news); nb++;
        }
}

int Correct(std::string filename)
    {
        int cor = 0;
        if (filename.find(DIRECTORY)!=string::npos) {return cor;}
        std::string text = LoadFile(filename);
        size_t pS = text.find("Turbine.PluginData.Save(");
        size_t pL = text.find("Turbine.PluginData.Load(");
        if ((pS == string::npos)&&(pL == string::npos)) {return cor;}
        cor += Replace(text,"Turbine.PluginData.Save(",DIRECTORY + string(".") + METHOD_SAVE + string("("));
        cor += Replace(text,"Turbine.PluginData.Load(",DIRECTORY + string(".") + METHOD_LOAD + string("("));
        string newtext = string("import \"") + DIRECTORY + string(".") + PATCHFILE + string("\"\n");
        newtext += text;
        SaveFile(filename,newtext);
        return cor;
    }

bool ListFiles(string path, string mask, vector<string>& files) {
    HANDLE hFind = INVALID_HANDLE_VALUE;
    WIN32_FIND_DATA ffd;
    string spec;
    stack<string> directories;
    directories.push(path);
    files.clear();
    while (!directories.empty()) {
        path = directories.top();
        spec = path + "\\" + mask;
        directories.pop();
        hFind = FindFirstFile(spec.c_str(), &ffd);
        if (hFind == INVALID_HANDLE_VALUE)  {
            return false;
        } 
        do {
            if (strcmp(ffd.cFileName, ".") != 0 && 
                strcmp(ffd.cFileName, "..") != 0) {
                if (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                    directories.push(path + "\\" + ffd.cFileName);
                }
                else {
                    files.push_back(path + "\\" + ffd.cFileName);
                }
            }
        } while (FindNextFile(hFind, &ffd) != 0);
        if (GetLastError() != ERROR_NO_MORE_FILES) {
            FindClose(hFind);
            return false;
        }
        FindClose(hFind);
        hFind = INVALID_HANDLE_VALUE;
    }
    return true;
}

int PatchLUAFiles()
{
    vector<string> files;
    string path;
    char szPath[MAX_PATH+1];
    if (SUCCEEDED(SHGetFolderPath(NULL,CSIDL_PERSONAL|CSIDL_FLAG_CREATE,NULL,0,szPath))) {path+=szPath; path+= "\\The Lord of the Rings Online\\Plugins";} else {MessageBox(NULL,"Error 4","",MB_OK); exit(0);}
    files.clear();
    int nbp =0;
    ListFiles(path, "*.*", files);
    for (vector<string>::iterator it = files.begin(); it != files.end(); ++it) 
        {
        size_t l = it->length();
        if (l>5)
            {
                if ((((*it)[l-1]) == 'a') && (((*it)[l-2]) == 'u') && (((*it)[l-3]) == 'l') && (((*it)[l-4]) == '.'))
                    {
                        int a = Correct(it->c_str());
                        if (a!=0) 
                            {
                            string z = it->substr(path.length());
                            cout << "- " << z << " [" << a << " change(s)]\n";
                            nbp++;
                            }
                    }
            }
        }
    return nbp;
}

int main(int argc, char* argv[])
{
    cout << "Starting Patching files...\n\n";
    int n = PatchLUAFiles();
    cout << "\n\n... done !\n";
    std::string s;
    std::stringstream out;
    out << n;
    s = out.str();
    s+= " file(s) patched !";
    MessageBox(NULL,s.c_str(),"ApplyPatch",MB_OK);
    return 0;
}

